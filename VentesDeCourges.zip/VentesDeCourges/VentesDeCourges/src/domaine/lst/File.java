package domaine.lst;

public interface File {


        void add(int val);
        int remove();
        boolean isEmpty();
    }

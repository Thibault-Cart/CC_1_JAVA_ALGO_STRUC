package domaine;

public class VenteAnnuelleEnNb extends VenteAnnuelle {
    public VenteAnnuelleEnNb(int annee, int nb) { super(annee, nb); }
}
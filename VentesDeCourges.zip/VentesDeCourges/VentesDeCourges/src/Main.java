public class Main {
    public static void main(String[] args) {
        new metier.VentesDeCourges();       // test de votre application
        new outils.ApplicationComptable();  // effectue la comptabilisation des écritures en attente
    }
}